
<?php
include 'koneksi.php';

$sql = "SELECT * FROM mahasiswa ORDER BY id DESC";
$result = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Mahasiswa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            padding: 30px;
        }

        h2 {
            color: #2563eb;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        th, td {
            border: 1px solid #cbd5e1;
            padding: 10px;
            text-align: left;
        }

        th {
            background: #2563eb;
            color: white;
        }

        a {
            display: inline-block;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

    <h2>Data Mahasiswa</h2>

    <a href="form_mahasiswa.php">+ Tambah Mahasiswa</a>

    <table>
        <tr>
            <th>ID</th>
            <th>NIM</th>
            <th>Nama</th>
            <th>Program Studi</th>
            <th>Email</th>
        </tr>

        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <td><?= htmlspecialchars($row['nim']) ?></td>
            <td><?= htmlspecialchars($row['nama']) ?></td>
            <td><?= htmlspecialchars($row['program_studi']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
        </tr>
        <?php } ?>
    </table>

</body>
</html>
