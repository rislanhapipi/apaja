
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Data Mahasiswa</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            padding: 30px;
        }

        .student-form {
            max-width: 450px;
            margin: 30px auto;
            padding: 25px;
            border: 1px solid #cbd5e1;
            border-radius: 10px;
            background: white;
            box-sizing: border-box;
        }

        h2 {
            text-align: center;
            color: #2563eb;
        }

        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 6px;
        }

        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #cbd5e1;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 20px;
            background: #2563eb;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <div class="student-form">
        <h2>Form Data Mahasiswa</h2>

        <form action="proses_tambah.php" method="POST">
            <label for="nim">NIM</label>
            <input type="text" id="nim" name="nim" required>

            <label for="nama">Nama Lengkap</label>
            <input type="text" id="nama" name="nama" required>

            <label for="program_studi">Program Studi</label>
            <input type="text" id="program_studi"
                   name="program_studi" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <button type="submit">Simpan Data</button>
        </form>
    </div>

</body>
</html>
