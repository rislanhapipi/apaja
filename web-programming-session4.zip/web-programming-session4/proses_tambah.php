
<?php
include 'koneksi.php';

$nim = $_POST['nim'] ?? '';
$nama = $_POST['nama'] ?? '';
$program_studi = $_POST['program_studi'] ?? '';
$email = $_POST['email'] ?? '';

$sql = "INSERT INTO mahasiswa
        (nim, nama, program_studi, email)
        VALUES (?, ?, ?, ?)";

$stmt = mysqli_prepare($koneksi, $sql);

if (!$stmt) {
    die("Gagal menyiapkan query: " . mysqli_error($koneksi));
}

mysqli_stmt_bind_param(
    $stmt,
    "ssss",
    $nim,
    $nama,
    $program_studi,
    $email
);

if (mysqli_stmt_execute($stmt)) {
    header("Location: data_mahasiswa.php?status=sukses");
    exit;
} else {
    die("Gagal menyimpan data: " . mysqli_stmt_error($stmt));
}
?>
